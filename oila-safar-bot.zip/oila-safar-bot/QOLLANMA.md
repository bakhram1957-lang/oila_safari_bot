# Oilaviy safar rejasi — bot

## 1. GitHub'ga yuklash

1. github.com'da yangi **Private** repository yarating (masalan: `oila-safar-bot`).
2. Ushbu papkadagi barcha fayl va papkalarni ("Add file" → "Upload files") repositoryga yuklang. `.github` papkasi ham albatta yuklanishi kerak.

## 2. Bot tokenini sir (secret) sifatida qo'shish

1. Repository sahifasida: **Settings → Secrets and variables → Actions → New repository secret**.
2. Name: `TELEGRAM_BOT_TOKEN`
3. Value: BotFather bergan tokeningiz.
4. **Add secret**.

## 3. O'zingizni asosiy qabul qiluvchi qilib belgilash

1. Telegram'da o'zingiz yaratgan botni topib, **/owner** buyrug'ini yuboring.
2. GitHub repository sahifasida: **Actions** bo'limiga kiring → "Kunlik safar rejasi" workflow'ni tanlang → **Run workflow** tugmasini bosing (qo'lda ishga tushirish).
3. Bir necha soniyadan so'ng botdan "Siz asosiy qabul qiluvchi sifatida belgilandingiz" degan xabar kelishi kerak.

Shundan keyin bot har kuni avtomatik ishlaydi (taxminan soat 20:00, Toshkent vaqti) — qo'lda ishga tushirish shart emas.

## 4. Oila a'zolari uchun: xabar qanday yuboriladi

Botga (xususiy chatda) ertangi kun uchun har bir safar haqida shu formatda, **4 qatorda** xabar yuboring:

```
19:00
Aziz
Uy
Bozor
```

Bir nechta kishi birga ketsa, Ism qatoriga vergul bilan yozing:

```
19:00
Aziz, Vali
Uy
Bozor
```

Har bir safar uchun alohida xabar yuboriladi. Xabarlar kechqurun soat 20:00 atrofida qayta ishlanadi — javob darhol kelmaydi, shuning uchun shoshilmang.

`/yordam` buyrug'i ham shu namunani qaytaradi.

## 5. Natija

Har kuni kechqurun siz (asosiy qabul qiluvchi) shaxsiy chatingizga ertangi reja bilan **Excel** va **Word** faylларini olasiz. Fayllarda har bir mashina/shofyor bo'yicha alohida jadval, va agar vaqt to'qnashuvi yoki sig'im muammosi bo'lsa — "DIQQAT" izohi bilan belgilanadi (bularni qo'lda tekshirib, kerak bo'lsa o'zgartiring).

## 6. Sozlamalarni o'zgartirish

`state/config.json` faylida shofyor ismlari, mashina modeli/sig'imi va safar davomiyligini (`trip_duration_minutes`, daqiqada) o'zgartirishingiz mumkin.
